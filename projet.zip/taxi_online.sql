create table admin (
   idutilisateur        serial                 not null,
   idadmin              int4                 not null,
   constraint pk_admin primary key (idutilisateur, idadmin)
);

create unique index admin_pk on admin (
idutilisateur,
idadmin
);

create  index generalisation_2_fk on admin (
idutilisateur
);

create table car (
   idcar                serial                 not null,
   immatriculation      varchar(254)         null,
   marque               varchar(254)         null,
   portiere             int4                 null,
   dateacquis           date                 null,
   constraint pk_car primary key (idcar)
);

create unique index car_pk on car (
idcar
);

create table chauffeur (
   idutilisateur        serial                 not null,
   idchauffeur          int4                 not null,
   permis               varchar(254)         null,
   capacite             varchar(254)         null,
   constraint pk_chauffeur primary key (idutilisateur, idchauffeur)
);

create unique index chauffeur_pk on chauffeur (
idutilisateur,
idchauffeur
);

create  index generalisation_4_fk on chauffeur (
idutilisateur
);

create table client (
   idutilisateur        serial                 not null,
   idclient             int4                 not null,
   address              varchar(254)         null,
   email                varchar(254)         null,
   constraint pk_client primary key (idutilisateur, idclient)
);

create unique index client_pk on client (
idutilisateur,
idclient
);

create  index generalisation_3_fk on client (
idutilisateur
);

create table destinataire (
   iddestination        serial                 not null,
   designation          varchar(254)         null,
   reference            varchar(254)         null,
   longitude            varchar(254)         null,
   latitude             varchar(254)         null,
   constraint pk_destinataire primary key (iddestination)
);

create unique index destinataire_pk on destinataire (
iddestination
);

create table paiement (
   idpaiement           serial                 not null,
   idreservation        int4                 not null,
   type                 varchar(254)         null,
   date                 date                 null,
   ref                  varchar(254)         null,
   constraint pk_paiement primary key (idpaiement)
);

create unique index paiement_pk on paiement (
idpaiement
);

create  index association_7_fk on paiement (
idreservation
);

create table proprietaire (
   idutilisateur        serial                 not null,
   idproprietaire       int4                 not null,
   adm_idutilisateur    int4                 not null,
   idadmin              int4                 not null,
   constraint pk_proprietaire primary key (idutilisateur, idproprietaire)
);

create unique index proprietaire_pk on proprietaire (
idutilisateur,
idproprietaire
);

create  index association_3_fk on proprietaire (
adm_idutilisateur,
idadmin
);

create  index generalisation_1_fk on proprietaire (
idutilisateur
);

create table reservation (
   idreservation        serial                 not null,
   idtaxi               int4                 not null,
   idutilisateur        int4                 not null,
   idclient             int4                 not null,
   iddestination        int4                 not null,
   datedebut            date                 null,
   etat                 varchar(254)         null,
   code                 varchar(254)         null,
   montant              int4                 null,
   constraint pk_reservation primary key (idreservation)
);

create unique index reservation_pk on reservation (
idreservation
);

create  index association_4_fk on reservation (
idtaxi
);

create  index association_5_fk on reservation (
iddestination
);

create  index association_6_fk on reservation (
idutilisateur,
idclient
);

create table taxi (
   idtaxi               serial                 not null,
   idcar                int4                 not null,
   idutilisateur        int4                 not null,
   idchauffeur          int4                 not null,
   pro_idutilisateur    int4                 not null,
   idproprietaire       int4                 not null,
   assurance            varchar(254)         null,
   nombreplace          int4                 null,
   clim                 bool                 null,
   numeroporte          int4                 null,
   constraint pk_taxi primary key (idtaxi)
);

create unique index taxi_pk on taxi (
idtaxi
);

create  index association_1_fk on taxi (
idutilisateur,
idchauffeur
);

create  index association_2_fk on taxi (
idcar
);

create  index association_8_fk on taxi (
pro_idutilisateur,
idproprietaire
);

create table utilisateur (
   idutilisateur        serial                 not null,
   nom                  varchar(254)         null,
   prenom               varchar(254)         null,
   numero               int4                 null,
   password             varchar(254)         null,
   constraint pk_utilisateur primary key (idutilisateur)
);

create unique index utilisateur_pk on utilisateur (
idutilisateur
);

alter table admin
   add constraint fk_admin_generalis_utilisat foreign key (idutilisateur)
      references utilisateur (idutilisateur)
      on delete restrict on update restrict;

alter table chauffeur
   add constraint fk_chauffeu_generalis_utilisat foreign key (idutilisateur)
      references utilisateur (idutilisateur)
      on delete restrict on update restrict;

alter table client
   add constraint fk_client_generalis_utilisat foreign key (idutilisateur)
      references utilisateur (idutilisateur)
      on delete restrict on update restrict;

alter table paiement
   add constraint fk_paiement_associati_reservat foreign key (idreservation)
      references reservation (idreservation)
      on delete restrict on update restrict;

alter table proprietaire
   add constraint fk_propriet_associati_admin foreign key (adm_idutilisateur, idadmin)
      references admin (idutilisateur, idadmin)
      on delete restrict on update restrict;

alter table proprietaire
   add constraint fk_propriet_generalis_utilisat foreign key (idutilisateur)
      references utilisateur (idutilisateur)
      on delete restrict on update restrict;

alter table reservation
   add constraint fk_reservat_associati_taxi foreign key (idtaxi)
      references taxi (idtaxi)
      on delete restrict on update restrict;

alter table reservation
   add constraint fk_reservat_associati_destinat foreign key (iddestination)
      references destinataire (iddestination)
      on delete restrict on update restrict;

alter table reservation
   add constraint fk_reservat_associati_client foreign key (idutilisateur, idclient)
      references client (idutilisateur, idclient)
      on delete restrict on update restrict;

alter table taxi
   add constraint fk_taxi_associati_chauffeu foreign key (idutilisateur, idchauffeur)
      references chauffeur (idutilisateur, idchauffeur)
      on delete restrict on update restrict;

alter table taxi
   add constraint fk_taxi_associati_car foreign key (idcar)
      references car (idcar)
      on delete restrict on update restrict;

alter table taxi
   add constraint fk_taxi_associati_propriet foreign key (pro_idutilisateur, idproprietaire)
      references proprietaire (idutilisateur, idproprietaire)
      on delete restrict on update restrict;

